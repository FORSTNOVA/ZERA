/*

Copyright (c) 2015, Arvid Norberg
All rights reserved.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "simulator/simulator.hpp"

#include <atomic>
#include <functional>

#include "simulator/push_warnings.hpp"
#include <boost/system/error_code.hpp>
#include "simulator/pop_warnings.hpp"

namespace sim { namespace chrono {
	namespace {

		// this is the global simulation timer, in nanoseconds since epoch.
		// fast_forward() and reset_clock() are only ever called from the
		// single simulation thread, but now() is also called concurrently
		// from real background threads (e.g. libtorrent's disk I/O threads),
		// so this needs to be safe for concurrent reads while the simulation
		// thread advances it.
		std::atomic<std::int64_t> g_simulation_time{0};
	}

	high_resolution_clock::time_point high_resolution_clock::now()
	{
		return high_resolution_clock::time_point(
			high_resolution_clock::duration(g_simulation_time.load(std::memory_order_relaxed)));
	}

	void high_resolution_clock::fast_forward(high_resolution_clock::duration d)
	{
		g_simulation_time.fetch_add(d.count(), std::memory_order_relaxed);
	}

	void reset_clock()
	{
		g_simulation_time.store(0, std::memory_order_relaxed);
	}

} // chrono
} // sim

